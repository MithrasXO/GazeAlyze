function comment = GA_gencode_comment(item)


switch item
    
    case 'dir'
    
        comment = {'testdir','+++++++++++++'};
        
    case ''
end;